import sqlite3
from sqlite3 import Error

def db_connect():
    try:
        con = sqlite3.connect('data.db')
        cur = con.cursor()
        return con, cur
    except Error as e:
        print(f"Error: {e}")


def db_disconnect(con):
    try:
        con.close()
    except Error as e:
        print(f"Error: {e}")