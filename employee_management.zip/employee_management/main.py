import tkinter as tk
import tkinter.ttk as ttk

from connect import db_connect, db_disconnect
from sqlite3 import Error


class TextboxStan(ttk.Entry):
    def __init__(self, container, R, C, **kwargs):
        super().__init__(container, **kwargs)
        self.grid(row=R, column=C, padx=5, pady=5)


class ListboxStan(tk.Listbox):
    def __init__(self, container, R, C, **kwargs):
        super().__init__(container, **kwargs)
        self.grid(row=R, column=C, padx=5, pady=5)


class ButtonStan(ttk.Button):
    def __init__(self, container, R, C, **kwargs):
        super().__init__(container, **kwargs)
        self.grid(row=R, column=C, padx=5, pady=5)


class LabelStan(ttk.Label):
    def __init__(self, container, R, C, **kwargs):
        super().__init__(container, **kwargs)
        self.grid(row=R, column=C, padx=5, pady=5)


class App:
    def __init__(self):
        self.frm_main = tk.Tk()
        self.frm_main.title("مدیریت کارگاه")

        self.hogoog_v = tk.Variable()
        self.hogoog = LabelStan(self.frm_main, 0, 0, text="حقوق این ماه")
        self.entry_hogoog = ListboxStan(self.frm_main, 1, 0, height=3, width=15, listvariable=self.hogoog_v)

        self.mablagh_v = tk.StringVar()
        self.mablagh = LabelStan(self.frm_main, 0, 1, text="مبلغ ساعت کار")
        self.entry_mablagh = TextboxStan(self.frm_main, 0, 2, textvariable=self.mablagh_v)

        self.saatkar_v = tk.StringVar()
        self.saatkar = LabelStan(self.frm_main, 1, 1, text="ساعت کار این ماه")
        self.entry_saatkar = TextboxStan(self.frm_main, 1, 2, textvariable=self.saatkar_v)

        self.lname_v = tk.StringVar()
        self.lname = LabelStan(self.frm_main, 0, 3, text="نام خانوادگی کارگر")
        self.entry_lname = TextboxStan(self.frm_main, 0, 4, textvariable=self.lname_v)

        self.date_v = tk.StringVar()
        self.date = LabelStan(self.frm_main, 1, 3, text="تاریخ استخدام")
        self.entry_date = TextboxStan(self.frm_main, 1, 4, textvariable=self.date_v)

        self.name_v = tk.StringVar()
        self.name = LabelStan(self.frm_main, 0, 5, text="نام کارگر")
        self.entry_name = TextboxStan(self.frm_main, 0, 6, textvariable=self.name_v)

        self.code_v = tk.StringVar()
        self.code = LabelStan(self.frm_main, 1, 5, text="کدملی")
        self.entry_code = TextboxStan(self.frm_main, 1, 6, textvariable=self.code_v)

        self.workers = []
        self.lst_workers_v = tk.Variable()
        self.lst_workers = ListboxStan(self.frm_main, 2, 0, height=5,width=70, listvariable=self.lst_workers_v)
        self.lst_workers.grid(rowspan=4, columnspan=4,sticky="NSEW")
        self.lst_workers.bind("<<ListboxSelect>>", self.lst_workers_select)
        self.get_workers()
        self.scroll = tk.Scrollbar(self.frm_main, orient=tk.VERTICAL, command=self.lst_workers.yview)
        self.scroll.grid(row=2, column=1, sticky="ns", rowspan=4,columnspan=7)
        self.scroll.config(command=self.lst_workers.yview)

        for i in range(5):
            self.lst_workers.insert(tk.END)

        self.btn_view = ButtonStan(self.frm_main, 3, 6, text="مشاهده همه", command=self.get_workers_c)
        self.btn_aad = ButtonStan(self.frm_main, 3, 5, text="اضافه کردن", command=self.btn_aad_c)
        self.btn_rem = ButtonStan(self.frm_main, 4, 5, text="حذف کردن", command=self.btn_rem_c)
        self.btn_sort = ButtonStan(self.frm_main, 4, 6, text="مرتب کردن", command=self.btn_sort_c)
        self.btn_search = ButtonStan(self.frm_main, 5, 6, text="جستجو", command=self.btn_search_c)
        self.btn_exit = ButtonStan(self.frm_main, 5, 5, text="خروج", command=self.btn_exit_c)

    def lst_workers_select(self, event):
        select = self.lst_workers.curselection()

        if not select:
            return  # No item selected
        index = select[0]
        part = self.lst_workers.get(index)

        data = part.split()

        if len(data) >= 2:
            self.entry_name.delete(0, tk.END)
            self.entry_name.insert(0, data[1])

            self.entry_lname.delete(0, tk.END)
            self.entry_lname.insert(0, data[2])

            self.entry_code.delete(0, tk.END)
            self.entry_code.insert(0, data[3])

            self.entry_date.delete(0, tk.END)
            self.entry_date.insert(0, data[4])

            self.entry_mablagh.delete(0, tk.END)
            self.entry_mablagh.insert(0, data[5])

            self.entry_saatkar.delete(0, tk.END)
            self.entry_saatkar.insert(0, data[6])

            self.entry_hogoog.delete(0, tk.END)
            self.entry_hogoog.insert(0, data[8])

    def btn_search_c(self):
        try:
            # Retrieve values from entry fields for search criteria
            name = self.entry_name.get()

            # Build the query with non-empty search criteria
            search_query = "SELECT * FROM worker WHERE 1=1"
            params = []

            if name:
                search_query += " AND name LIKE ?"
                params.append(f"%{name}%")
            # Execute the search query
            con, cur = db_connect()
            cur.execute(search_query, params)
            results = cur.fetchall()
            db_disconnect(con)

            # Clear the ListBox and display search results
            self.lst_workers.delete(0, tk.END)
            for result in results:
                name = result
                detail = f"{len(self.lst_workers.get(0, tk.END)) + 1}: {name} "
                self.lst_workers.insert(tk.END, detail)

        except:
            pass

    def get_workers(self):
        pass

    def btn_sort_c(self):
        workers = list(self.lst_workers.get(0, tk.END))
        n = len(workers)

        for i in range(n):
            for j in range(0, n - i - 1):
                if workers[j] > workers[j + 1]:
                    workers[j], workers[j + 1] = workers[j + 1], workers[j]
        self.lst_workers.delete(tk.END)
        for worker in workers:
            self.lst_workers.insert(tk.END, worker)

    def get_workers_c(self):
        try:
            con, cur = db_connect()
            cmd = "SELECT * FROM worker"
            cur.execute(cmd)
            rows = cur.fetchall()
            self.lst_workers.delete(0, tk.END)
            for row in rows:
                id, fn, ln, code, date, mablagh, saatkar, hogoog = row[:8]
                datail = f"{id}_Fullname: {fn} {ln} {code} {date} {mablagh} {saatkar} Salary: {hogoog}"
                self.lst_workers.insert(tk.END, datail)
            db_disconnect(con)
        except:
            pass

    def btn_aad_c(self):
        name = self.entry_name.get().title()
        lname = self.entry_lname.get().title()
        code = self.entry_code.get()
        date = self.entry_date.get()
        mablagh = self.entry_mablagh.get()
        saatkar = self.entry_saatkar.get()

        saatkar = int(self.entry_saatkar.get())
        mablagh = int(self.entry_mablagh.get())
        calc = lambda saatkar, mablagh: saatkar * mablagh
        monthly = calc(saatkar, mablagh)
        salary_str = f"{monthly}"
        self.hogoog_v.set(salary_str)

        if name and lname and code and date and saatkar and mablagh and salary_str:
            detail = f"Fullname:{name} {lname} {code} {date} {saatkar} {mablagh} Salary: {salary_str}"
            self.workers.append(detail)
            self.lst_workers.insert(tk.END, detail)

            con, cur = db_connect()
            if len(cur.fetchall()) == 0:
                cmd = "INSERT INTO worker(name,lname,code,date,mablagh,saatkar,hogoog) VALUES(?,?,?,?,?,?,?)"
                cur.execute(cmd, (name, lname, code, date, mablagh, saatkar, salary_str))
                con.commit()
            db_disconnect(con)
            self.name_v.set("")
            self.lname_v.set("")
            self.code_v.set("")
            self.date_v.set("")
            self.saatkar_v.set("")
            self.mablagh_v.set("")
            self.hogoog_v.set("")

    def btn_exit_c(self):
        self.frm_main.quit()

    def btn_rem_c(self):
        index = self.lst_workers.curselection()[0]
        select = self.lst_workers.get(index)
        detail = select.split("_")[0]
        con, cur = db_connect()
        cmd = "DELETE FROM worker WHERE worker_id=?"
        cur.execute(cmd, (detail,))
        con.commit()
        db_disconnect(con)
        self.lst_workers.delete(index)

        self.name_v.set("")
        self.lname_v.set("")
        self.code_v.set("")
        self.date_v.set("")
        self.saatkar_v.set("")
        self.mablagh_v.set("")
        self.hogoog_v.set("")

    def run(self):
        self.frm_main.mainloop()


app = App()
app.run()
