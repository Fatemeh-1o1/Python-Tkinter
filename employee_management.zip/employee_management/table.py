from connect import db_connect,db_disconnect
from sqlite3 import Error

try:
    con,cur = db_connect()

    # cmd="CREATE TABLE worker(worker_id INTEGER PRIMARY KEY,name text,lname text,code integer,date integer,mablagh integer,saatkar integer,hogoog integer)"
    cmd="SELECT * FROM worker"
    cur.execute(cmd)
    con.commit()
    print(cur.fetchall())
    db_disconnect(con)
except Error as e:
    print(f"Error: {e}")